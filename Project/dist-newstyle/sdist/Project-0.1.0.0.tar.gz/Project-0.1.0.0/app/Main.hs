module Main where

import Graphics.Gloss

import Game
import Logic
import Rendering

window = Blank

main :: IO ()
main = display (InWindow "Nice Window" (200, 200) (10, 10)) white (Circle 80)
