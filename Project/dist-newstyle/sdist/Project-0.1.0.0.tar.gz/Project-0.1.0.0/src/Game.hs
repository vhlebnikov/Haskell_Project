module Game where

someFunc :: IO ()
someFunc = print (factorial 10)

factorial :: Int -> Int
factorial n = product [1..n]
